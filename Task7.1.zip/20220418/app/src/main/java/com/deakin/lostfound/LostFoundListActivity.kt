package com.deakin.lostfound

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_lost_found_list.*

class LostFoundListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lost_found_list)

        setListView()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == 0) {
            // refresh
            setListView()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    fun setListView() {
        val sp = getSharedPreferences("sp", MODE_PRIVATE)
        val str = sp.getString("list", "")
        val gson = Gson()
        val models = gson.fromJson(str, Array<LostModel>::class.java) ?: listOf<LostModel>().toTypedArray()

        list_view.adapter = CustomAdapter(models, object: OnItemClickListener{
            override fun onItemClick(model: LostModel) {
                val gson = Gson()
                startActivityForResult(Intent(this@LostFoundListActivity, DetailActivity::class.java).putExtra("model", gson.toJson(model)), 1)
            }
        })
        list_view.layoutManager = LinearLayoutManager(this)
    }
}