package com.deakin.lostfound

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_create_advert.*
import java.util.*

class CreateAdvertActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_advert)

        btn.setOnClickListener {
            saveModel()
        }
    }

    fun saveModel() {
        val isLost = findViewById<Button>(radio.checkedRadioButtonId).text == "Lost"
        val nameStr = name.text.toString()
        val despStr = desp.text.toString()
        val phoneStr = phone.text.toString()
        val dateStr = date.text.toString()
        val locationStr = location.text.toString()

        if (nameStr.isEmpty() || despStr.isEmpty() || phoneStr.isEmpty() || dateStr.isEmpty() || locationStr.isEmpty()) {
            return
        }

        val sp = getSharedPreferences("sp", MODE_PRIVATE)
        val edit = sp.edit()
        val gson = Gson()
        val json = sp.getString("list", "")
        var models = gson.fromJson(json, Array<LostModel>::class.java)
        if (models == null) {
            models = listOf<LostModel>().toTypedArray()
        }
        val list: MutableList<LostModel> = models.toMutableList()
        list.add(LostModel(nameStr, despStr, isLost, phoneStr, dateStr, locationStr))
        edit.putString("list", gson.toJson(list))
        edit.apply()

        finish()
    }
}