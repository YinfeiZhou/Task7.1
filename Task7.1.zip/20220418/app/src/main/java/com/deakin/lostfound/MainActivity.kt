package com.deakin.lostfound

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn1.setOnClickListener {
            startActivity(Intent(this, CreateAdvertActivity::class.java))
        }

        btn2.setOnClickListener {
            startActivity(Intent(this, LostFoundListActivity::class.java))
        }

        btn3.setOnClickListener {
            startActivity(Intent(this, LostFoundListActivity::class.java))
        }
    }
}