package com.deakin.lostfound

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_create_advert.*
import kotlinx.android.synthetic.main.activity_create_advert.btn
import kotlinx.android.synthetic.main.activity_detail.*


class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val model = Gson().fromJson(intent.getStringExtra("model"), LostModel::class.java)

        model.apply {
            text1.text = (if (isLost) "Lost" else "Found") + " " + name
            text2.text = model.date
            text3.text = model.location
            text4.text = model.phone
            text5.text = model.desp
        }

        btn.setOnClickListener {
            val sp = getSharedPreferences("sp", MODE_PRIVATE)
            val edit = sp.edit()
            val gson = Gson()
            val json = sp.getString("list", "")
            var models = gson.fromJson(json, Array<LostModel>::class.java)
            if (models == null) {
                models = listOf<LostModel>().toTypedArray()
            }
            val list: MutableList<LostModel> = mutableListOf<LostModel>()
            models.forEach {
                if (it == model) {
                    return@forEach
                } else {
                    list.add(it)
                }
            }
            edit.putString("list", gson.toJson(list))
            edit.apply()
            setResult(0)
            finish()
        }
    }
}