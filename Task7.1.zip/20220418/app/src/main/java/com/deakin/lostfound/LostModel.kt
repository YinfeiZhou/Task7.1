package com.deakin.lostfound

import java.util.*

data class LostModel(
    val name: String,
    val desp: String,
    val isLost: Boolean,
    val phone: String,
    val date: String,
    val location: String
)